---
name: ffmpeg-auto-subtitle
description: 把字幕硬烧进视频：可直接烧录你已有的 srt，也可用本地 whisper 免费识别配音自动生成字幕再烧录——静音刷也能看字。
---

# 自动字幕识别与烧录（FFmpeg 自动执行）

> 淘宝店：AI灵匣 · 自动剪辑与批量导出(FFmpeg)

## 一句话定位
把字幕硬烧进视频：可直接烧录你已有的 srt，也可用本地 whisper 免费识别配音自动生成字幕再烧录——静音刷也能看字。

## ⚠️ 这是真·自动执行技能（和 01-07 指引型不同）
本技能附带 `scripts/` 下的 Python 脚本，调用你本地 FFmpeg **直接产出成片**，不是只给方案。

## 环境依赖
- FFmpeg（免费开源）：本地安装并加入 PATH。脚本会自动查找；找不到时尝试调用 `imageio-ffmpeg` 自带的 ffmpeg。
- Python 3.8+
- 字幕识别（可选）：`pip install openai-whisper`（本地模型，免费，无需 API 密钥）

## 什么时候用
- 依赖：🟡 需本地 FFmpeg；字幕识别可选 whisper（本地免费）
- 接入点：可承接 01-07 各环节的产出（脚本/分镜/粗剪方案/调色参数），把"方案"落地成"文件"

## 工作流（照做即可）
1. 本技能附带 scripts/auto_subtitle.py，两种用法：
2. 
3. ① 烧录已有字幕（--srt）：你手头有 srt（比如用原包「06 字幕生成」产出的文本自己对齐的，或剪映识别导出的），直接硬烧进视频，平台静音播放也带字。
4. ② 语音识别生成（--transcribe）：调用本地 whisper 模型识别配音，自动出 srt 再烧录。whisper 是本地开源模型，完全免费、不需要任何 API 密钥，首次会自动下载模型。
5. 
6. 字幕样式用 force_style 指定中文黑体（微软雅黑）+ 白字黑描边，任何背景都看得清。对应原工作流「06 字幕与画面包装」——把"出字幕文本"升级成"出带字幕的成片"。纯本地，零付费依赖。

## 运行命令（真实可复制）
```bash
cd <技能目录>
python scripts/auto_subtitle.py <参数>
```

## 真实触发例句（可直接复制）
- 把我这段口播视频的字幕（sub.srt）硬烧进去，静音也能看
- 用本地 whisper 识别这段配音，自动生成字幕并烧录
- 字幕字体用微软雅黑，白字黑边

## 产出样例
命令示例（烧录已有字幕）：
python scripts/auto_subtitle.py --input 成片.mp4 --output 带字幕.mp4 --srt sub.srt

命令示例（本地识别）：
python scripts/auto_subtitle.py --input 成片.mp4 --output 带字幕.mp4 --transcribe --model base

输出：带字幕.mp4（字幕已硬编码进画面）

## 衔接
→ 输出成片可继续进本包其他环节，或直接发布。08 类内：拼接 → 字幕 → 调色 → 多平台导出 可经 `ffmpeg-pipeline` 一键串联。

## 常见问题
- Q：识别要钱吗？ A：whisper 本地跑，免费，无需密钥；首次下载模型 base 约 140MB。
- Q：中文识别准吗？ A：base 够用，要求高用 small/medium；可指定 --model。
- Q：字幕文件编码？ A：srt 用 UTF-8，避免乱码。
- Q：会覆盖原片吗？ A：输出到新文件，原片不动。

---
淘宝店：AI灵匣 整理 · 淘宝店：AI灵匣