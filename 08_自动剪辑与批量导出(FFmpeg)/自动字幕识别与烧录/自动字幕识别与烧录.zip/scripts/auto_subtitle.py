# -*- coding: utf-8 -*-
"""自动字幕识别与烧录（自动执行）· AI灵匣
两种用法：
  1) 烧录已有字幕：--srt sub.srt  → 把字幕硬烧进视频（平台静音刷也能看）。
  2) 语音识别生成：--transcribe   → 本地 whisper 识别配音生成 srt 再烧录（免费、本地、无需 API 密钥）。
纯本地运行，零外部付费 API。依赖本地 FFmpeg；字幕识别可选依赖 openai-whisper（本地模型）。
"""
import argparse, os, shutil, subprocess, sys

def ffmpeg_exec():
    exe = shutil.which("ffmpeg")
    if exe:
        return exe
    try:
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        pass
    return "ffmpeg"

def burn(ff, src, srt, dst, font="Microsoft YaHei"):
    # ffmpeg subtitles 滤镜：用绝对路径(正斜杠)，force_style 指定中文黑体+描边
    # Windows 路径处理：libass 需要原生反斜杠，且盘符冒号(C:)与反斜杠都需转义，
    # 否则 ffmpeg 把冒号当选项分隔符、把反斜杠吞掉导致打不开文件。
    srt_path = os.path.abspath(srt).replace("\\", "\\\\").replace(":", "\\:")
    style = ("FontSize=28,FontName=%s,PrimaryColour=&HFFFFFF&,"
             "OutlineColour=&H000000&,Outline=2,Shadow=1,"
             "Alignment=2,MarginV=40" % font)
    vf = "subtitles=filename='%s':force_style='%s'" % (srt_path, style)
    cmd = [ff, "-y", "-i", src, "-vf", vf,
           "-c:v", "libx264", "-preset", "medium", "-crf", "20",
           "-pix_fmt", "yuv420p", "-c:a", "copy", os.path.abspath(dst)]
    print("[ffmpeg]", " ".join(cmd))
    r = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    if r.returncode != 0:
        print(r.stdout.decode("utf-8", "ignore"))
        raise RuntimeError("字幕烧录失败（检查 srt 路径/编码是否为 UTF-8）")
    print("\n✅ 字幕已烧录：%s" % dst)

def transcribe(src, srt, model="base"):
    try:
        import whisper
    except Exception:
        raise SystemExit(
            "未安装 whisper。本地免费识别请先执行：\n"
            "  pip install openai-whisper\n"
            "（识别在本地跑，不需要任何 API 密钥；首次会下载模型 %s）" % model)
    print("[whisper] 加载模型 %s ..." % model)
    m = whisper.load_model(model)
    print("[whisper] 识别中：%s" % src)
    res = m.transcribe(src, language="zh", word_timestamps=False)
    with open(srt, "w", encoding="utf-8") as f:
        i = 0
        for seg in res["segments"]:
            i += 1
            start = seg["start"]; end = seg["end"]; text = seg["text"].strip()
            f.write("%d\n%s --> %s\n%s\n\n" % (
                i, _srt_time(start), _srt_time(end), text))
    print("[whisper] 已生成字幕：%s" % srt)

def _srt_time(t):
    h = int(t // 3600); t -= h * 3600
    m = int(t // 60); t -= m * 60
    s = int(t); ms = int((t - s) * 1000)
    return "%02d:%02d:%02d,%03d" % (h, m, s, ms)

def main():
    ap = argparse.ArgumentParser(description="自动字幕识别与烧录")
    ap.add_argument("--input", required=True, help="输入视频")
    ap.add_argument("--output", required=True, help="输出视频 .mp4")
    ap.add_argument("--srt", help="已有字幕文件 .srt（UTF-8）")
    ap.add_argument("--transcribe", action="store_true", help="用本地 whisper 识别配音")
    ap.add_argument("--model", default="base", help="whisper 模型 base/small/medium")
    ap.add_argument("--font", default="Microsoft YaHei", help="字幕字体（中文用微软雅黑等）")
    a = ap.parse_args()

    ff = ffmpeg_exec()
    outdir = os.path.dirname(os.path.abspath(a.output))
    os.makedirs(outdir, exist_ok=True)

    srt = os.path.join(outdir, "_sub_temp.srt")
    if a.transcribe:
        transcribe(a.input, srt, a.model)
    elif a.srt:
        srt = a.srt
    else:
        raise SystemExit("请指定 --srt <字幕文件> 或 --transcribe（本地识别）")
    burn(ff, a.input, srt, a.output, a.font)
    if a.transcribe:
        try:
            os.remove(srt)
        except Exception:
            pass

if __name__ == "__main__":
    main()
