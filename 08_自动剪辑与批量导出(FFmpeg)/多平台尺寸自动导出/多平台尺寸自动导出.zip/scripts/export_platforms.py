# -*- coding: utf-8 -*-
"""多平台尺寸自动导出（自动执行）· AI灵匣
把一个成片自动导出为多平台尺寸：抖音 9:16、小红书 3:4、B站 16:9、方形 1:1。
比例不符时用「模糊背景+居中前景」填充（主流短视频平台做法），不拉伸变形。
纯本地运行，零外部付费 API；依赖本地 FFmpeg（未装则尝试 imageio-ffmpeg 自带）。
"""
import argparse, os, shutil, subprocess

def ffmpeg_exec():
    exe = shutil.which("ffmpeg")
    if exe:
        return exe
    try:
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        pass
    return "ffmpeg"

PLATFORMS = {
    "douyin":   (1080, 1920, "9:16"),
    "xhs":      (1080, 1440, "3:4"),
    "bilibili": (1920, 1080, "16:9"),
    "square":   (1080, 1080, "1:1"),
}

def export_one(ff, src, dst, w, h):
    # 模糊背景铺满 + 前景等比缩放进画布居中
    vf = (
        f"[0:v]scale={w}:{h}:force_original_aspect_ratio=increase,crop={w}:{h},gblur=28,format=yuv420p[bg];"
        f"[0:v]scale={w}:{h}:force_original_aspect_ratio=decrease,pad={w}:{h}:(ow-iw)/2:(oh-ih)/2[fg];"
        f"[bg][fg]overlay=0:0"
    )
    # 双输入滤镜图必须用 -filter_complex（不是 -vf）
    cmd = [ff, "-y", "-i", src, "-filter_complex", vf,
           "-c:v", "libx264", "-preset", "medium", "-crf", "20",
           "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "128k", "-movflags", "+faststart",
           os.path.abspath(dst)]
    print("[ffmpeg]", " ".join(cmd))
    r = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    if r.returncode != 0:
        print(r.stdout.decode("utf-8", "ignore"))
        raise RuntimeError("导出 %s 失败" % dst)
    print("  ✅", dst)

def main():
    ap = argparse.ArgumentParser(description="多平台尺寸自动导出")
    ap.add_argument("--input", required=True, help="输入成片")
    ap.add_argument("--outdir", required=True, help="输出目录")
    ap.add_argument("--platforms", default="douyin,xhs,bilibili,square",
                    help="逗号分隔：douyin/xhs/bilibili/square")
    a = ap.parse_args()

    ff = ffmpeg_exec()
    os.makedirs(a.outdir, exist_ok=True)
    base = os.path.splitext(os.path.basename(a.input))[0]
    req = [p.strip() for p in a.platforms.split(",") if p.strip()]
    for p in req:
        if p not in PLATFORMS:
            print("[跳过] 未知平台 %s" % p)
            continue
        w, h, ratio = PLATFORMS[p]
        dst = os.path.join(a.outdir, f"{base}_{p}_{w}x{h}.mp4")
        print("\n[导出 %s %s (%s)]" % (p, f"{w}x{h}", ratio))
        export_one(ff, a.input, dst, w, h)
    print("\n✅ 全部导出完成，目录：%s" % os.path.abspath(a.outdir))

if __name__ == "__main__":
    main()
