# -*- coding: utf-8 -*-
"""FFmpeg 自动调色与画质增强（自动执行）· AI灵匣
按预设对视频做调色/画质增强，输出成片。可选预设：通透 / 胶片 / 冷调 / 日系 / 原片增强。
纯本地运行，零外部付费 API；依赖本地 FFmpeg（未装则尝试 imageio-ffmpeg 自带）。
"""
import argparse, os, shutil, subprocess

def ffmpeg_exec():
    exe = shutil.which("ffmpeg")
    if exe:
        return exe
    try:
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        pass
    return "ffmpeg"

PRESETS = {
    "tongs": {  # 通透：提亮、加对比饱和、轻微锐化
        "vf": ("eq=brightness=0.03:contrast=1.12:saturation=1.15:gamma=0.95,"
               "unsharp=luma_msize_x=5:luma_msize_y=5:luma_amount=1.1:chroma_msize_x=3:chroma_msize_y=3:chroma_amount=0.5")
    },
    "film": {  # 胶片：中对比、降饱和、暗角
        "vf": ("eq=contrast=1.10:saturation=0.88:gamma=1.04:brightness=-0.01,"
               "vignette=PI/4:0.35")
    },
    "cold": {  # 冷调：偏冷、轻微降亮
        "vf": ("eq=brightness=-0.015:contrast=1.08:saturation=0.95,"
               "colorchannelmixer=rr=0.94:gg=1.0:bb=1.06")
    },
    "jp": {  # 日系：提亮、降对比、微增饱和
        "vf": ("eq=brightness=0.05:contrast=0.92:saturation=1.05,"
               "gblur=0.4")
    },
    "enhance": {  # 原片增强：去噪+锐化，不改变色调
        "vf": ("hqdn3d=2:1:2:3,"
               "unsharp=luma_msize_x=5:luma_msize_y=5:luma_amount=1.2")
    },
}

def main():
    ap = argparse.ArgumentParser(description="FFmpeg 自动调色与画质增强")
    ap.add_argument("--input", required=True, help="输入视频")
    ap.add_argument("--output", required=True, help="输出视频 .mp4")
    ap.add_argument("--preset", default="tongs", help="tongs/film/cold/jp/enhance")
    ap.add_argument("--strength", type=float, default=1.0, help="强度倍率 0.5-1.5")
    a = ap.parse_args()

    ff = ffmpeg_exec()
    if a.preset not in PRESETS:
        raise SystemExit("未知预设 %s，可选：%s" % (a.preset, "/".join(PRESETS)))
    vf = PRESETS[a.preset]["vf"]
    if a.strength != 1.0:
        # 用 g 表达式无法简单缩放，这里仅对 eq 的亮度/对比/饱和做近似缩放提示
        print("[提示] 强度参数仅作记录，预设滤镜已按标准强度应用；如需微调可自行改滤镜。")
    outdir = os.path.dirname(os.path.abspath(a.output))
    os.makedirs(outdir, exist_ok=True)
    cmd = [ff, "-y", "-i", a.input, "-vf", vf,
           "-c:v", "libx264", "-preset", "medium", "-crf", "18",
           "-pix_fmt", "yuv420p", "-c:a", "copy", os.path.abspath(a.output)]
    print("[ffmpeg]", " ".join(cmd))
    r = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    if r.returncode != 0:
        print(r.stdout.decode("utf-8", "ignore"))
        raise RuntimeError("调色失败")
    print("\n✅ 完成：%s （预设=%s）" % (a.output, a.preset))

if __name__ == "__main__":
    main()
