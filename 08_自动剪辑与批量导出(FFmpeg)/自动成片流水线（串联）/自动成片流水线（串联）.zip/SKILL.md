---
name: ffmpeg-pipeline
description: 一条命令串联全流程：预处理拼接 →（可选）字幕烧录 →（可选）调色增强 → 多平台导出。丢素材自动出多平台成片。
---

# 自动成片流水线（串联）（FFmpeg 自动执行）

> 淘宝店：AI灵匣 · 自动剪辑与批量导出(FFmpeg)

## 一句话定位
一条命令串联全流程：预处理拼接 →（可选）字幕烧录 →（可选）调色增强 → 多平台导出。丢素材自动出多平台成片。

## ⚠️ 这是真·自动执行技能（和 01-07 指引型不同）
本技能附带 `scripts/` 下的 Python 脚本，调用你本地 FFmpeg **直接产出成片**，不是只给方案。

## 环境依赖
- FFmpeg（免费开源）：本地安装并加入 PATH。脚本会自动查找；找不到时尝试调用 `imageio-ffmpeg` 自带的 ffmpeg。
- Python 3.8+
- 字幕识别（可选）：`pip install openai-whisper`（本地模型，免费，无需 API 密钥）

## 什么时候用
- 依赖：🟡 需本地 FFmpeg；字幕识别可选 whisper
- 接入点：可承接 01-07 各环节的产出（脚本/分镜/粗剪方案/调色参数），把"方案"落地成"文件"

## 工作流（照做即可）
1. 本技能附带 scripts/pipeline.py，是 08 类的"总开关"——把前面 4 个自动技能串成一条流水线，实现「丢素材进去、多平台成片出来」的真·自动剪辑。
2. 
3. 你写一份 manifest.json：列出素材（或素材文件夹）、目标分辨率、是否加字幕、调色预设、要哪些平台。运行一条命令，它依次调用：
4. 拼接 → 字幕（可选）→ 调色（可选）→ 多平台导出，
5. 最后在输出目录给你 00_拼接成片 / 01_字幕成片 / 02_调色成片 / 各平台版本。
6. 
7. manifest 里的 clips/subtitle/color_preset 可直接来自 08_方案→成片桥接器：把 01 口播稿转成 srt、把 03 粗剪清单转成 manifest、把 07 调色名直接映射成 preset。这样 01-07 的方案层才真正驱动 08 的执行层。

## 运行命令（真实可复制）
```bash
cd <技能目录>
python scripts/pipeline.py <参数>
```

## 真实触发例句（可直接复制）
- 写个 manifest，把我的口播素材自动拼成片并导出抖音和小红书
- 给我一份 pipeline 的 manifest.json 模板
- 这条流水线要加字幕和通透调色，然后出全平台

## 产出样例
manifest.json 示例：
{
  "clips": ["素材/a.mp4","素材/b.mp4"],
  "output_dir": "./成片",
  "resolution": {"w":1080,"h":1920},
  "fps": 30,
  "subtitle": "字幕.srt",
  "color_preset": "tongs",
  "platforms": ["douyin","xhs","bilibili"]
}

命令：python scripts/pipeline.py --manifest manifest.json
输出：成片/ 下多平台成片

## 衔接
→ 输出成片可继续进本包其他环节，或直接发布。08 类内：拼接 → 字幕 → 调色 → 多平台导出 可经 `ffmpeg-pipeline` 一键串联。

## 常见问题
- Q：字幕怎么开？ A：manifest 里 "subtitle": true 走本地 whisper；或 "subtitle": "sub.srt" 烧已有字幕。推荐用 08_方案→成片桥接器把 01 口播稿转成 srt，零识别误差。
- Q：能只拼接不调色？ A：color_preset 设为 null 或删掉该字段即跳过。
- Q：素材必须自有吗？ A：是的，用你自有或 CC0 合规素材，别搬运他人视频。

---
淘宝店：AI灵匣 整理 · 淘宝店：AI灵匣