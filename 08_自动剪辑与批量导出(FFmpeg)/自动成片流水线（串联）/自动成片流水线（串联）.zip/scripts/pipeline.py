# -*- coding: utf-8 -*-
"""自动成片流水线（串联执行）· AI灵匣
一条命令把「你的素材文件夹」变成「多平台可发成片」：
  预处理拼接 → (可选)字幕烧录 → (可选)调色增强 → 多平台尺寸导出
纯本地运行，零外部付费 API。依赖本地 FFmpeg；字幕识别可选 whisper。

manifest.json 示例：
{
  "clips": ["素材/a.mp4", "素材/b.mp4"],   // 或填一个素材文件夹路径
  "output_dir": "./成片",
  "resolution": {"w": 1080, "h": 1920},
  "fps": 30,
  "subtitle": false,                       // true 需 whisper，或用 "srt":"xxx.srt"
  "color_preset": "tongs",                 // null 跳过调色
  "platforms": ["douyin", "xhs", "bilibili"]
}
"""
import argparse, os, sys, json, subprocess, shutil

HERE = os.path.dirname(os.path.abspath(__file__))

def run_python(script, args):
    py = sys.executable
    cmd = [py, os.path.join(HERE, script)] + args
    print("\n>>>", " ".join(cmd))
    r = subprocess.run(cmd)
    if r.returncode != 0:
        raise RuntimeError("%s 执行失败" % script)

def main():
    ap = argparse.ArgumentParser(description="自动成片流水线")
    ap.add_argument("--manifest", required=True, help="流水线清单 manifest.json")
    a = ap.parse_args()

    with open(a.manifest, encoding="utf-8") as f:
        cfg = json.load(f)

    outdir = cfg.get("output_dir", "./成片")
    os.makedirs(outdir, exist_ok=True)
    res = cfg.get("resolution", {"w": 1080, "h": 1920})
    w, h, fps = res.get("w", 1080), res.get("h", 1920), cfg.get("fps", 30)

    clips = cfg.get("clips")
    if isinstance(clips, str):
        clip_arg = clips
    elif isinstance(clips, list):
        # 写成临时 txt 给 prep_concat
        tmp = os.path.join(outdir, "_concat.txt")
        with open(tmp, "w", encoding="utf-8") as f:
            for c in clips:
                f.write(c.replace("\\", "/") + "\n")
        clip_arg = tmp
    else:
        raise SystemExit("manifest.clips 必须是 文件列表 或 素材文件夹路径")

    concat_out = os.path.join(outdir, "00_拼接成片.mp4")
    print("【步骤1/4】预处理拼接")
    run_python("prep_concat.py", ["--input", clip_arg, "--output", concat_out,
                                   "--w", str(w), "--h", str(h), "--fps", str(fps)])

    current = concat_out

    sub_cfg = cfg.get("subtitle", False)
    if sub_cfg:
        print("【步骤2/4】字幕")
        sub_out = os.path.join(outdir, "01_字幕成片.mp4")
        if isinstance(sub_cfg, str):  # 给了 srt 路径
            run_python("auto_subtitle.py", ["--input", current, "--output", sub_out, "--srt", sub_cfg])
        else:
            run_python("auto_subtitle.py", ["--input", current, "--output", sub_out, "--transcribe",
                                            "--model", cfg.get("whisper_model", "base")])
        current = sub_out

    color = cfg.get("color_preset")
    if color:
        print("【步骤3/4】调色增强 preset=%s" % color)
        color_out = os.path.join(outdir, "02_调色成片.mp4")
        run_python("auto_color.py", ["--input", current, "--output", color_out, "--preset", color])
        current = color_out

    platforms = cfg.get("platforms", ["douyin", "xhs", "bilibili", "square"])
    print("【步骤4/4】多平台导出")
    run_python("export_platforms.py", ["--input", current, "--outdir", outdir,
                                        "--platforms", ",".join(platforms)])

    print("\n🎬 全流程完成！成片在：%s" % os.path.abspath(outdir))

if __name__ == "__main__":
    main()
