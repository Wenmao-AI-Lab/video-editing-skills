# -*- coding: utf-8 -*-
"""调色预设 中文名 ↔ FFmpeg preset 映射（方案层→执行层 桥接器 #4）· AI灵匣
让 07 类「调色预设应用」技能说的中文名（通透/胶片/冷调/日系/原片增强），
直接对接 08 类 auto_color.py 的 --preset 参数，方案层与执行层调色语义统一。

用法：
  python color_map.py --list                      # 打印全部映射
  python color_map.py --cn 通透                   # 输出 tongs
  python color_map.py --cn 通透 --input x.mp4 --output y.mp4   # 直接调 auto_color
"""
import argparse, os, sys, subprocess

COLOR_ALIAS = {
    "通透": "tongs", "胶片": "film", "冷调": "cold",
    "日系": "japan", "原片增强": "native", "增强": "native",
    "tongs": "tongs", "film": "film", "cold": "cold",
    "japan": "japan", "native": "native",
}
HERE = os.path.dirname(os.path.abspath(__file__))


def main():
    ap = argparse.ArgumentParser(description="调色预设名映射")
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--cn", help="中文调色名或英文 preset")
    ap.add_argument("--input", help="若给定，直接调 auto_color 处理")
    ap.add_argument("--output", help="auto_color 输出")
    a = ap.parse_args()

    if a.list or not a.cn:
        print("调色预设映射表（方案层中文 ↔ 执行层 preset）：")
        for cn, en in [("通透", "tongs"), ("胶片", "film"), ("冷调", "cold"),
                       ("日系", "japan"), ("原片增强", "native")]:
            print("   %-6s ↔ %s" % (cn, en))
        if not a.cn:
            return

    preset = COLOR_ALIAS.get(a.cn)
    if not preset:
        raise SystemExit("不认识的调色名：%s（用 --list 查看）" % a.cn)
    print("✅ %s → preset=%s" % (a.cn, preset))

    if a.input:
        if not a.output:
            a.output = os.path.splitext(a.input)[0] + "_color.mp4"
        py = sys.executable
        cmd = [py, os.path.join(HERE, "auto_color.py"),
               "--input", a.input, "--output", a.output, "--preset", preset]
        print(">>>", " ".join(cmd))
        subprocess.run(cmd, check=True)


if __name__ == "__main__":
    main()
