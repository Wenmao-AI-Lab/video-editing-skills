# -*- coding: utf-8 -*-
"""口播稿 / 台词 → 标准字幕 SRT（方案层→执行层 桥接器 #1）· AI灵匣
把 01 类「口播文案生成」技能产出的纯文本口播稿，转成 FFmpeg 可直接烧录的 .srt。
彻底绕开 whisper 语音识别（未验证分支），只要你有稿子就能出字幕。

用法：
  python script_to_srt.py --input 口播稿.txt --output 字幕.srt
  python script_to_srt.py --input 口播稿.txt --output 字幕.srt --speed 4 --gap 0.3
  python script_to_srt.py --input 口播稿.txt --output 字幕.srt --total 30   # 按总时长均分

稿子格式约定（宽松，自动兼容）：
  - 空行分段；每行一句，或整段由标点(。！？；\n)自动断句
  - 行内写 [停顿2s] 表示该处额外停顿 2 秒（用于句间留白、转场）
  - 行内写 [入点12.5] / [出点15.0] 可手动指定该句时间轴（高级，可选）
"""
import argparse, os, re


def split_sentences(text):
    """按换行 + 中文/英文句号断句，保留标点。"""
    raw_lines = [l.strip() for l in text.splitlines() if l.strip()]
    sentences = []
    for line in raw_lines:
        # 先按显式 [停顿] 切，避免把停顿标记吞进句子
        parts = re.split(r'(\[停顿\d+\.?\d*s?\])', line)
        for p in parts:
            p = p.strip()
            if not p:
                continue
            if re.fullmatch(r'\[停顿\d+\.?\d*s?\]', p):
                sentences.append(('PAUSE', p))
                continue
            # 按标点断句
            for s in re.split(r'(?<=[。！？；\.!?;])', p):
                s = s.strip()
                if s:
                    sentences.append(('TEXT', s))
    return sentences


def parse_pause(tok):
    m = re.search(r'(\d+\.?\d*)', tok)
    return float(m.group(1)) if m else 0.0


def main():
    ap = argparse.ArgumentParser(description="口播稿转 SRT 字幕")
    ap.add_argument("--input", required=True, help="口播稿/台词 .txt（UTF-8）")
    ap.add_argument("--output", required=True, help="输出 .srt")
    ap.add_argument("--speed", type=float, default=4.0, help="语速 字/秒（中文口播 3~5，默认 4）")
    ap.add_argument("--gap", type=float, default=0.25, help="句间基础间隔(秒)")
    ap.add_argument("--total", type=float, default=0.0, help="若指定，按总时长均分(忽略speed)")
    a = ap.parse_args()

    text = open(a.input, encoding="utf-8").read()
    units = split_sentences(text)
    if not units:
        raise SystemExit("口播稿为空或没有可断句的文本")

    # 计算每句时长
    durations = []
    for kind, val in units:
        if kind == 'PAUSE':
            durations.append(parse_pause(val))
        else:
            n = max(1, len(re.sub(r'\s', '', val)))  # 去空格后的字数
            durations.append(max(1.0, n / a.speed) + a.gap)

    if a.total > 0:
        # 按总时长均分（去掉停顿占用后均分给文本句）
        pause_sum = sum(d for (k, _), d in zip(units, durations) if k == 'PAUSE')
        text_units = [(k, v) for k, v in units if k == 'TEXT']
        per = (a.total - pause_sum) / max(1, len(text_units))
        durations = []
        for kind, val in units:
            if kind == 'PAUSE':
                durations.append(parse_pause(val))
            else:
                n = max(1, len(re.sub(r'\s', '', val)))
                durations.append(max(per, n / a.speed * 0.6 + 0.4))  # 仍保证长句稍久

    # 写 srt
    out_dir = os.path.dirname(os.path.abspath(a.output))
    os.makedirs(out_dir, exist_ok=True)
    t = 0.0
    idx = 0
    with open(a.output, "w", encoding="utf-8") as f:
        for (kind, val), d in zip(units, durations):
            if kind == 'PAUSE':
                t += d
                continue
            start = t
            end = t + d
            idx += 1
            f.write("%d\n%s --> %s\n%s\n\n" % (
                idx, _t(start), _t(end), val))
            t = end
    print("✅ 已生成字幕：%s（%d 句，总时长 %.1fs）" % (a.output, idx, t))


def _t(sec):
    h = int(sec // 3600); sec -= h * 3600
    m = int(sec // 60); sec -= m * 60
    s = int(sec); ms = int(round((sec - s) * 1000))
    if ms == 1000:
        ms = 0; s += 1
    return "%02d:%02d:%02d,%03d" % (h, m, s, ms)


if __name__ == "__main__":
    main()
