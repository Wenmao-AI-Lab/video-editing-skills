# -*- coding: utf-8 -*-
"""分镜 / 粗剪清单 → FFmpeg 拼接 manifest（方案层→执行层 桥接器 #2）· AI灵匣
把 03 类「粗剪拼接时间线生成」技能产出的片段清单，转成 08 类 pipeline.py 直接吃的 manifest.json。
这样 Agent 在方案层排好的「顺序+规格+字幕+调色」，不用手动改参数就能进入自动执行层。

清单格式（宽松，自动兼容）：
  每行一个片段，支持：
    素材路径
    素材路径 | 入点 | 出点          # 出入点(秒)，本桥仅记录，prep_concat 当前整段拼接
    # 注释行
  或写 JSON：{"clips":[...], "resolution":{"w":1080,"h":1920}, ...}

顶部可选配置行（# 开头后跟 key=value）：
    # resolution=1080x1920
    # fps=30
    # subtitle=口播稿.srt        # 或直接填 srt 路径
    # color_preset=tongs         # 通透/胶片/冷调/日系/原片增强 也认
    # platforms=douyin,xhs,bilibili
"""
import argparse, os, json, re


def parse_clip(line):
    parts = [p.strip() for p in line.split("|")]
    path = parts[0]
    inp = parts[1] if len(parts) > 1 and parts[1] else None
    outp = parts[2] if len(parts) > 2 and parts[2] else None
    return path, inp, outp


def main():
    ap = argparse.ArgumentParser(description="分镜清单转拼接 manifest")
    ap.add_argument("--input", required=True, help="分镜/粗剪清单 .txt 或 .json")
    ap.add_argument("--output", required=True, help="输出 manifest.json")
    ap.add_argument("--resolution", default="1080x1920")
    ap.add_argument("--fps", type=int, default=30)
    ap.add_argument("--subtitle", default="")
    ap.add_argument("--color_preset", default="")
    ap.add_argument("--platforms", default="douyin,xhs,bilibili,square")
    a = ap.parse_args()

    cfg = {
        "clips": [],
        "output_dir": "./成片",
        "resolution": {"w": 1080, "h": 1920},
        "fps": a.fps,
        "subtitle": a.subtitle or False,
        "color_preset": a.color_preset or None,
        "platforms": [p.strip() for p in a.platforms.split(",") if p.strip()],
    }
    w, h = (a.resolution.split("x") + ["1920", "1080"])[:2]
    cfg["resolution"] = {"w": int(w), "h": int(h)}

    raw = open(a.input, encoding="utf-8").read()
    if a.input.lower().endswith(".json"):
        data = json.loads(raw)
        cfg.update({k: v for k, v in data.items() if k in cfg})
        # 兼容中文预设名
        if isinstance(cfg.get("color_preset"), str) and cfg["color_preset"] in COLOR_ALIAS:
            cfg["color_preset"] = COLOR_ALIAS[cfg["color_preset"]]
    else:
        clips_meta = []
        for line in raw.splitlines():
            line = line.strip()
            if not line:
                continue
            if line.startswith("#"):
                kv = line.lstrip("#").strip()
                if "=" in kv:
                    k, v = kv.split("=", 1)
                    k, v = k.strip(), v.strip()
                    if k == "resolution":
                        w, h = (v.split("x") + ["1920", "1080"])[:2]
                        cfg["resolution"] = {"w": int(w), "h": int(h)}
                    elif k == "fps":
                        cfg["fps"] = int(v)
                    elif k == "subtitle":
                        cfg["subtitle"] = v or False
                    elif k == "color_preset":
                        cfg["color_preset"] = COLOR_ALIAS.get(v, v) or None
                    elif k == "platforms":
                        cfg["platforms"] = [p.strip() for p in v.split(",") if p.strip()]
                continue
            if line.startswith("//"):
                continue
            path, inp, outp = parse_clip(line)
            cfg["clips"].append(path)
            if inp or outp:
                clips_meta.append({"path": path, "in": inp, "out": outp})
        if clips_meta:
            cfg["_clip_ranges"] = clips_meta  # 出入点记录（未来 prep_concat 支持时启用）

    if not cfg["clips"]:
        raise SystemExit("清单里没有任何素材路径")
    if not cfg["subtitle"]:
        cfg["subtitle"] = False
    if not cfg["color_preset"]:
        cfg["color_preset"] = None

    out_dir = os.path.dirname(os.path.abspath(a.output))
    os.makedirs(out_dir, exist_ok=True)
    with open(a.output, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)
    print("✅ 已生成 manifest：%s" % a.output)
    print("   片段数=%d  分辨率=%sx%s  fps=%d  字幕=%s  调色=%s" % (
        len(cfg["clips"]), cfg["resolution"]["w"], cfg["resolution"]["h"], cfg["fps"],
        cfg["subtitle"], cfg["color_preset"]))


COLOR_ALIAS = {
    "通透": "tongs", "胶片": "film", "冷调": "cold",
    "日系": "japan", "原片增强": "native", "增强": "native",
}

if __name__ == "__main__":
    main()
