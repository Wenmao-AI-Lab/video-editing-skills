# -*- coding: utf-8 -*-
"""音频能量分析 → 切点 JSON（方案层→执行层 桥接器 #3）· AI灵匣
把音频抽成 PCM，用 Python 直接计算滑动窗 RMS（dB），找静音段边界，作为 04 类
「节奏卡点」的真实数据：自动在哪切、转场放哪；也用于 03 类「废片/静音片段」筛选。
纯本地、零依赖、免费，不依赖任何付费 API。比解析 ffmpeg metadata 更稳更准。

用法：
  python beatdetect.py --input 配音.wav --output 切点.json
  python beatdetect.py --input 成片.mp4 --output 切点.json --silence -40   # 静音阈值dB
"""
import argparse, os, shutil, subprocess, re, json, struct, math, tempfile


def ffmpeg_exec():
    exe = shutil.which("ffmpeg")
    if exe:
        return exe
    try:
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        pass
    return "ffmpeg"


def extract_pcm(ff, src, sr=16000):
    tmp = tempfile.mktemp(suffix=".pcm")
    cmd = [ff, "-y", "-i", src, "-vn", "-ac", "1", "-ar", str(sr),
           "-f", "s16le", tmp]
    r = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    err = r.stdout.decode("utf-8", "ignore")
    if r.returncode != 0:
        # 无音轨/无音频流时，优雅返回空（而不是崩溃）
        if any(x in err for x in ["does not contain any stream", "No audio streams", "Invalid argument"]):
            return [], sr
        raise RuntimeError("无法抽取音频 PCM：%s" % err[-300:])
    if not os.path.getsize(tmp):
        return [], sr
    data = open(tmp, "rb").read()
    os.remove(tmp)
    n = len(data) // 2
    samples = struct.unpack("<%dh" % n, data[:n * 2])
    return samples, sr


def analyze(samples, sr, silence_db, win=0.05):
    win_n = max(1, int(sr * win))
    silences = []
    in_sil = False
    seg = None
    total = len(samples)
    # 预先转 float
    arr = [s / 32768.0 for s in samples]
    i = 0
    while i + win_n <= total:
        chunk = arr[i:i + win_n]
        rms = math.sqrt(sum(x * x for x in chunk) / len(chunk))
        db = 20 * math.log10(rms + 1e-9)
        t = i / sr
        is_sil = db < silence_db
        if is_sil and not in_sil:
            in_sil = True
            seg = {"start": round(t, 2), "end": round(t, 2)}
        elif is_sil and in_sil:
            seg["end"] = round(t, 2)
        elif not is_sil and in_sil:
            in_sil = False
            if seg["end"] - seg["start"] > 0.3:
                silences.append(seg)
        i += win_n
    if in_sil and seg and seg["end"] - seg["start"] > 0.3:
        silences.append(seg)
    cuts = [round((s["start"] + s["end"]) / 2, 2) for s in silences]
    return {"cuts": cuts, "silences": silences, "silence_db": silence_db,
            "sample_rate": sr, "duration_sec": round(total / sr, 2)}


def main():
    ap = argparse.ArgumentParser(description="音频能量分析→切点")
    ap.add_argument("--input", required=True, help="音频或含音视频文件")
    ap.add_argument("--output", required=True, help="输出切点 .json")
    ap.add_argument("--silence", type=float, default=-40.0, help="静音阈值 dB（默认 -40）")
    ap.add_argument("--win", type=float, default=0.05, help="滑动窗秒（默认 0.05）")
    a = ap.parse_args()

    ff = ffmpeg_exec()
    samples, sr = extract_pcm(ff, a.input)
    res = analyze(samples, sr, a.silence, a.win)
    out_dir = os.path.dirname(os.path.abspath(a.output))
    os.makedirs(out_dir, exist_ok=True)
    with open(a.output, "w", encoding="utf-8") as f:
        json.dump(res, f, ensure_ascii=False, indent=2)
    print("✅ 切点已生成：%s" % a.output)
    print("   时长 %.1fs，静音段 %d 个，建议切点 %d 个：%s" % (
        res["duration_sec"], len(res["silences"]), len(res["cuts"]), res["cuts"]))


if __name__ == "__main__":
    main()
