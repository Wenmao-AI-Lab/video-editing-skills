---
name: ffmpeg-bridge
description: 把 01/03/04/07 类技能产出的"方案"（口播稿/粗剪清单/切点/调色名）转换成 08 类自动成片流水线能直接消费的机器可读中间文件（srt / manifest.json / 切点.json）。
---

# 方案→成片桥接器（中间产物转换）（FFmpeg 自动执行）

> 淘宝店：AI灵匣 · 自动剪辑与批量导出(FFmpeg)

## 一句话定位
把 01/03/04/07 类技能产出的"方案"（口播稿/粗剪清单/切点/调色名）转换成 08 类自动成片流水线能直接消费的机器可读中间文件（srt / manifest.json / 切点.json）。

## ⚠️ 这是真·自动执行技能（和 01-07 指引型不同）
本技能附带 `scripts/` 下的 Python 脚本，调用你本地 FFmpeg **直接产出成片**，不是只给方案。

## 环境依赖
- FFmpeg（免费开源）：本地安装并加入 PATH。脚本会自动查找；找不到时尝试调用 `imageio-ffmpeg` 自带的 ffmpeg。
- Python 3.8+
- 字幕识别（可选）：`pip install openai-whisper`（本地模型，免费，无需 API 密钥）

## 什么时候用
- 依赖：🟢 零门槛（beatdetect/color_map 需 FFmpeg）
- 接入点：可承接 01-07 各环节的产出（脚本/分镜/粗剪方案/调色参数），把"方案"落地成"文件"

## 工作流（照做即可）
1. 前面 01-07 类技能产出的是"给人看的方案"，08 类脚本吃的是"给机器读的参数文件"——两者之间缺少一座桥，所以全流程看起来"断"的。本技能就是那座桥。
2. 
3. 附带 4 个桥接脚本：
4. ① script_to_srt.py：把 01 类产出的"口播稿.txt"转成标准 .srt 字幕文件，直接喂给 auto_subtitle/pipeline，彻底绕开 whisper 识别。
5. ② storyboard_to_manifest.py：把 03 类产出的"粗剪清单.txt"转成 pipeline 能吃的 manifest.json（含 clips / resolution / fps / subtitle / color_preset / platforms）。
6. ③ beatdetect.py：分析音频能量，输出"切点表.json"（静音段边界），给 04 类卡点做真实数据，也用于自动分段/转场。
7. ④ color_map.py：把 07 类的中文调色名（通透/胶片/冷调/日系/原片增强）映射成 auto_color.py 的 --preset 参数，统一调色语义。
8. 
9. 没有这些桥，01-07 和 08 就是两套不相干的工具；有了这些桥，方案层才真能把执行层跑起来。

## 运行命令（真实可复制）
```bash
cd <技能目录>
python scripts/script_to_srt.py <参数>
```

## 真实触发例句（可直接复制）
- 把这份口播稿转成 srt 字幕文件，我要用 pipeline 烧录
- 把这份粗剪清单转成 manifest.json 让 pipeline 自动拼接
- 这份音频帮我找出静音切点，输出切点表

## 产出样例
命令示例：
python scripts/script_to_srt.py --input 口播稿.txt --output 字幕.srt --speed 4
python scripts/storyboard_to_manifest.py --input 粗剪清单.txt --output manifest.json
python scripts/beatdetect.py --input 配音.wav --output 切点.json --silence -40
python scripts/color_map.py --cn 通透   # 输出 tongs

输出：srt / manifest.json / 切点.json / preset 名，可直接被 pipeline 消费

## 衔接
→ 输出成片可继续进本包其他环节，或直接发布。08 类内：拼接 → 字幕 → 调色 → 多平台导出 可经 `ffmpeg-pipeline` 一键串联。

## 常见问题
- Q：桥接器需要 FFmpeg 吗？ A：script_to_srt 和 storyboard_to_manifest 是纯文件转换，不需要；beatdetect 和 color_map 需要 FFmpeg 处理音频/视频。
- Q：口播稿格式有要求吗？ A：每句一行即可，支持 [停顿2s] 标记；会自动按字数/语速分配时间轴。
- Q：粗剪清单格式？ A：每行一个素材路径，顶部可写 # resolution=1080x1920 / # color_preset=通透 / # platforms=douyin,xhs。
- Q：调色名映射表？ A：通透↔tongs、胶片↔film、冷调↔cold、日系↔japan、原片增强↔native。

---
淘宝店：AI灵匣 整理 · 淘宝店：AI灵匣