# -*- coding: utf-8 -*-
"""素材批量预处理与拼接（FFmpeg 自动执行）· AI灵匣
把一组本地素材批量统一规格（分辨率/帧率/像素格式/音频）后，按清单顺序拼接成一段成片。
纯本地运行，零外部付费 API；FFmpeg 免费开源，需本地安装并加入 PATH（未装则自动尝试 imageio-ffmpeg 自带 ffmpeg）。
"""
import argparse, os, sys, subprocess, tempfile, glob, shutil, json

def ffmpeg_exec():
    exe = shutil.which("ffmpeg")
    if exe:
        return exe
    try:
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        pass
    return "ffmpeg"

def run(cmd):
    print("[ffmpeg]", " ".join(cmd))
    r = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    if r.returncode != 0:
        print(r.stdout.decode("utf-8", "ignore"))
        raise RuntimeError("ffmpeg 执行失败，返回码 %d" % r.returncode)
    return r

def norm_one(ff, src, dst, w, h, fps):
    vf = (f"scale={w}:{h}:force_original_aspect_ratio=decrease,"
          f"pad={w}:{h}:(ow-iw)/2:(oh-ih)/2,setsar=1,fps={fps}")
    # 用静音音轨兜底，保证每条都有音频可拼接
    cmd = [ff, "-y", "-i", src,
           "-f", "lavfi", "-i", "anullsrc=channel_layout=mono:sample_rate=44100",
           "-shortest", "-vf", vf,
           "-map", "0:v:0", "-map", "1:a:0",
           "-c:v", "libx264", "-preset", "medium", "-crf", "20",
           "-pix_fmt", "yuv420p", "-c:a", "aac", "-ar", "44100", "-ac", "1", "-b:a", "128k",
           dst]
    run(cmd)

def build_order(input_arg):
    # input_arg: 文件夹路径，或 concat.txt（每行一个文件路径），或 json 清单
    if input_arg.lower().endswith(".json"):
        with open(input_arg, encoding="utf-8") as f:
            data = json.load(f)
        files = data.get("clips", [])
        if not files:
            raise ValueError("manifest 缺少 clips 列表")
        return files
    if os.path.isdir(input_arg):
        exts = ("*.mp4", "*.mov", "*.mkv", "*.avi", "*.webm", "*.MP4", "*.MOV")
        files = []
        for e in exts:
            files += glob.glob(os.path.join(input_arg, e))
        # Windows 上 glob 大小写不敏感，*.mp4 与 *.MP4 会重复匹配，去重
        files = list(dict.fromkeys(files))
        files.sort()
        return files
    if input_arg.lower().endswith(".txt"):
        with open(input_arg, encoding="utf-8") as f:
            return [l.strip() for l in f if l.strip() and not l.strip().startswith("#")]
    return [input_arg]

def main():
    ap = argparse.ArgumentParser(description="素材批量预处理与拼接")
    ap.add_argument("--input", required=True, help="素材文件夹 / concat.txt / manifest.json")
    ap.add_argument("--output", required=True, help="输出成片路径 .mp4")
    ap.add_argument("--w", type=int, default=1080)
    ap.add_argument("--h", type=int, default=1920)
    ap.add_argument("--fps", type=int, default=30)
    ap.add_argument("--keep", action="store_true", help="保留中间归一化文件")
    a = ap.parse_args()

    ff = ffmpeg_exec()
    files = build_order(a.input)
    if not files:
        raise SystemExit("没有找到可拼接的素材")
    print("待拼接 %d 条：" % len(files))
    for f in files:
        print("  -", f)

    tmp = tempfile.mkdtemp(prefix="prep_")
    norm = []
    for i, src in enumerate(files):
        dst = os.path.join(tmp, "n%03d.mp4" % i)
        print("\n[归一化 %d/%d] %s" % (i + 1, len(files), src))
        norm_one(ff, src, dst, a.w, a.h, a.fps)
        norm.append(dst)

    # concat demuxer
    list_txt = os.path.join(tmp, "list.txt")
    with open(list_txt, "w", encoding="utf-8") as f:
        for n in norm:
            f.write("file '%s'\n" % n.replace("\\", "/"))

    outdir = os.path.dirname(os.path.abspath(a.output))
    os.makedirs(outdir, exist_ok=True)
    print("\n[拼接] ->", a.output)
    cmd = [ff, "-y", "-f", "concat", "-safe", "0", "-i", list_txt,
           "-c", "copy", os.path.abspath(a.output)]
    run(cmd)
    if not a.keep:
        shutil.rmtree(tmp, ignore_errors=True)
    print("\n✅ 完成：%s （%d 条素材已预处理并拼接）" % (a.output, len(files)))

if __name__ == "__main__":
    main()
