---
name: jianying-draft-gen
description: 把 08 桥接器产出的 manifest.json（含 clips/resolution/fps/subtitle）直接转换成剪映草稿工程(.draft/draft_content.json)，让方案层 01-07 的产出也能在剪映里一键自动成片。与 ffmpeg 线共用同一份 manifest，实现"一个方案、两条渲染线"。
---

# 剪映草稿自动生成（方案→剪映草稿）

> 淘宝店：AI灵匣 · 剪映自动成片

## 一句话定位
把 08 桥接器产出的 `manifest.json`（视频剪辑包「双线贯通」架构的通用中间产物）直接转成**剪映草稿工程**，让方案层 01-07 的智能规划也能在剪映里"自动铺好时间线"，买家打开剪映点一下导出就出片。

## ⚠️ 这是第二条自动线（和 08 ffmpeg 线并列）
- 08 类（FFmpeg 线）：`manifest.json` → 命令行直接渲染成片，全程无需打开剪辑软件。
- 本技能（剪映线）：`manifest.json` → 剪映草稿工程，买家在剪映里打开即可见排好的视频轨/字幕轨/音频轨，点「导出」出片。
- **两者吃同一份 `manifest.json`**——这就是"一个方案、两条渲染线"：你用 ffmpeg 还是剪映，由买家按习惯二选一，方案层 01-07 的产出都不浪费。

## 环境依赖
- Python 3.8+
- `pyJianYingDraft`（免费开源，仅生成草稿 JSON，不需要剪映本体安装）：`pip install pyJianYingDraft`
- ffmpeg（免费开源，仅用于探测素材真实时长，让片段时间轴对齐）：本地安装并加入 PATH；找不到时脚本自动尝试 `imageio-ffmpeg` 自带 ffmpeg。

## 什么时候用
- 依赖：🟡 需剪映（买家侧）· 生成阶段仅 `pyJianYingDraft` + ffmpeg
- 接入点：承接 08 桥接器 `storyboard_to_manifest.py` 产出的 `manifest.json`，把"方案"落成"剪映可打开的工程"

## 工作流（照做即可）
1. 前面 01-07 类技能产出"方案"（脚本/分镜/粗剪/字幕/调色），经 08 桥接器 `storyboard_to_manifest.py` 落成 `manifest.json`。
2. 本技能读 `manifest.json`：按素材真实时长顺序铺视频轨；字幕轨直接吃 manifest 里的 `.srt`（与 ffmpeg 烧录同一份）；可选铺标题轨、音频轨。
3. 输出 `xxx.draft/draft_content.json`——把该文件夹放进剪映「草稿」目录，打开即见完整时间线，点导出即出片。

## 运行命令（真实可复制）
```bash
cd <技能目录>
pip install pyJianYingDraft
python scripts/gen_jianying_draft.py --manifest manifest.json --output 我的视频.draft --title "片头标题" --audio bgm.mp3
```

## 真实触发例句（可直接复制）
- 把这份 manifest.json 转成剪映草稿，我要在剪映里导出
- 方案层已经排好粗剪清单了，帮我生成剪映工程，别让我手动拖素材
- 用同一份 manifest，给我一条 ffmpeg 线、一条剪映线，我自己选

## 产出样例
输入 manifest.json：
```json
{
  "clips": ["clip1.mp4", "clip2.mp4"],
  "resolution": {"w":1080,"h":1920},
  "fps": 30,
  "subtitle": "口播稿.srt",
  "color_preset": "tongs",
  "platforms": ["douyin","xhs"]
}
```
命令：
```bash
python scripts/gen_jianying_draft.py --manifest manifest.json --output 成片_剪映.draft --title "双线贯通演示"
```
输出：`成片_剪映.draft/draft_content.json`（视频轨 2 段 + 字幕轨 + 标题轨），放进剪映草稿目录即可。

## 衔接
→ 输入与 08 `ffmpeg-pipeline` 完全一致（同一个 manifest.json），两条线可并行对比。
→ 调色：剪映线保留 07 类调色预设名，买家在剪映里一键套用对应 LUT/滤镜即可（ffmpeg 线则由 auto_color 自动处理）。

## 常见问题
- Q：生成草稿需要装剪映吗？ A：不需要。生成阶段只用 `pyJianYingDraft` 写 JSON；剪映只用于最后打开草稿、点导出。
- Q：和 ffmpeg 线冲突吗？ A：不冲突，共用 manifest。想全自动用 ffmpeg 线；想用剪映精修/套模板用本线。
- Q：字幕怎么来的？ A：直接吃 manifest 里的 `.srt`（即 01 类口播稿经 `script_to_srt.py` 生成的同一份），两条线字幕一致。
- Q：素材时长对不齐怎么办？ A：脚本用 ffmpeg 探测每个素材真实时长并按顺序排布，无需手动算。

---
淘宝店：AI灵匣 整理 · 淘宝店：AI灵匣
